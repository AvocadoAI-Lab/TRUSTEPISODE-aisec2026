# TrustEpisode Frozen Contracts

本目錄是論文附錄引用的 machine-readable reproducibility companion。它固定方法與評估契約，但不聲稱尚未執行的實驗已完成。

## 檔案

| 檔案 | 用途 |
|---|---|
| `trustepisode_online.v1.schema.json` | 八種 online objects、封閉欄位、型別、enum、nullability、digest 與 fail-closed 條件 |
| `detector_registry.v1.json` | 六個固定 detector IDs、finite value domain、方向、CDF tie、top-k、q/C 與去重規則 |
| `baseline_registry.v1.json` | EB1/EB2/SB1/SB2 的輸入、排序、ID、缺值、solver 與 artifact digest 契約 |
| `examples/audit_record.valid.json` | 受支援且可決策的 AuditRecord 範例 |
| `examples/audit_record.out_of_support.valid.json` | `P=null`、`decision_eligible=false` 的 out-of-support 範例 |
| `examples/assembly_failure.valid.json` | 無法安全組裝 AuditRecord 時的 terminal failure 範例 |
| `examples/late_evidence.valid.json` | 超過固定 revision horizon 後只進入 late store 的範例 |
| `examples/audit_record.reject-label.json` | 必須被 schema 拒絕的 label-leakage 範例 |
| `thresholds.v1.json` | Formation、detector availability、contradiction、assembly、matching、calibration gate 與 bootstrap 契約 |
| `split_policy.v1.json` | 每個 10-run stratum 可執行的 deterministic 50/20/10/20 split 與 descendant inheritance |
| `run_registry.template.csv` | 正式 run registry 欄位；只有 header，不含虛構 runs |
| `lab_manifest.v1.json` | CALDERA/OCSF pins、角色、每個 run 的必要欄位與 fail-closed 規則 |
| `scenario_cards.v1.json` | M1--M7、M5-ID、B1--B8 的 image/ability/command/timing/marker/success/failure/cleanup/mode contract |
| `perturbations.v1.json` | RP0--RP7 deterministic replay 與 PO1 physical-outage protocol |
| `result_registry.v1.json` | RT1--RT7 的 rows、columns、`pending` 與 `N/A` 規則 |
| `validate_contracts.py` | Schema、leakage rejection、canonical digest 與 manifest 驗證器 |
| `manifest.v1.json` | 本目錄交付檔案的 SHA-256 清單 |

## 核心閉合規則

1. Feature Extractor 只產生 health-independent `D`、`C`、source mask 與 detector observation。
2. Scope Resolver 結合 SourceCoverage，單獨產生 resolved detector state、calibration status、group key 與 eligibility。
3. 第一個 finalized revision 固定 900 秒 deadline；接受 late evidence 不會延長 deadline。
4. Beyond-horizon evidence 只產生 LateEvidenceRecord，不會改寫 EpisodeRevision 或 AuditRecord。
5. 每個 revision 只有一個 terminal AssemblyOutcome：AuditRecord 或 AssemblyFailureRecord。
6. `horizon_exceeded` 不屬於 AuditRecord 的 `U.lateness`，因為未建立 revision 的 evidence 不能回寫既有 record。
7. `C_dec_all` 保留 supported/OOS/failure outcomes；`C_dec_score` 只用於可評分 metrics，所有 coverage/failure rate 以 all-outcome denominator 回報。
8. RP0--RP7 由 domain-separated HMAC PRF 唯一映射到 source、event、interval、permutation 與 duplicate root。
9. 所有 JSON number 必須有限，且禁止 NaN、infinity 與 negative zero。
10. `eligible_detector_count=0` 必須輸出 out-of-support、false eligibility 與 null `P`，`no_detection` 不得繞過此規則。
11. Class-dependent metrics 只使用 positive/negative `C_dec_binary`；offline labels 在所有 terminal outcomes 插入後才 join。
12. RFC 8785 不重排 arrays；reference arrays 必須先依 application ordering 排序，optional absence 使用 closed sentinel。

## 驗證

```powershell
python artifacts\contracts\validate_contracts.py
```

驗證器要求：

1. 所有 valid examples 通過 Draft 2020-12 schema。
2. Label-leakage example 必須失敗。
3. 每個 canonical digest 必須與宣告欄位相符。
4. `manifest.v1.json` 的 byte count 與 SHA-256 必須吻合。
5. 尚未執行的 result cells 保持 `pending`，不得以零或虛構數值取代。

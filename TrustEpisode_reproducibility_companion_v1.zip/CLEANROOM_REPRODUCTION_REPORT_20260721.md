# Clean-room reproduction report (DFRWS P0)

- Generated (UTC): `2026-07-21T14:12:06.738978+00:00`
- Companion ZIP: `TrustEpisode_reproducibility_companion_v1.zip`
- Companion SHA-256: `de65a73794ada7a732509dccc0a05bfd918d5120aa21fa3f716086ffc7163dd2`
- Clean-room root: `C:\Users\admin\Desktop\aisec\TRUSTEPISODE-aisec2026\tmp\cleanroom-dfrws-p0`
- Overall: **PASS**

## Checks

### `scripts/generate_tables.py` — PASS (exit 0)

```
{"n_runs": 60, "d1_pass": 60, "d1_exec": 600, "audit_pass": 18, "audit_fail_codes": 7, "tax_pass": 8, "tax_total": 8}
```

### `scripts/verify_claims.py` — PASS (exit 0)

```
{
  "ok": true,
  "failures": [],
  "n_failures": 0
}
```

### `C:\Users\admin\Desktop\aisec\TRUSTEPISODE-aisec2026\scripts\run_temporal_boundary_fixtures.py` — PASS (exit 0)

```
{"all_pass": true, "n_cases": 7, "output": "C:\\Users\\admin\\Desktop\\aisec\\TRUSTEPISODE-aisec2026\\results\\derived\\temporal_boundary_conformance.json", "sha256": "e9d7314b5cecafc93ed57b9f3d8cff5fd13433e4a1c02fc59f0080c108a56788", "pytest_tail": ".......                                                                  [100%]"}
```

## Interpretation

This clean-room extract verifies that the packed companion regenerates LaTeX macros,
passes `verify_claims.py`, and that temporal boundary fixtures
(299/300/301 and 3599/3600/3601/3900) pass against the production synthesizer.
It does not re-execute live CALDERA collection.

Machine-readable: `results/derived/cleanroom_reproduction.json` (sha256 `1223f20f2ad1b6d2cd84dca140ba8bcf951f418dd31567cc2a08c8695da64a4b`).

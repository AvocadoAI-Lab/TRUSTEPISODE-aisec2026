# TrustEpisode reproducibility companion (DFRWS revision)

## One-command checks (from this directory)

```
python scripts/generate_tables.py
python scripts/run_targeted_cards.py
python scripts/run_determinism_matrix_60.py
python scripts/run_audit_conformance_a12.py
python scripts/run_taxonomy_ag.py
python scripts/run_audit_baselines_ab.py
python scripts/verify_claims.py
```

## Expected

- fair_baselines.json: EB1--EB4 identical on M1--M6; 60/60 ties vs sliding-time
- fair_baselines_m1m7.json: offline 70-run M1--M7 re-synthesis (descriptive; no superiority claim)
- table4_amended: primary M1--M6 cells; M7 is supplemental boundary-stress only
- temporal_boundary_conformance.json: 299/300/301 and 3599/3600/3601/3900 all pass
- determinism_matrix.json: D1 60/60; D2 raw 0/60; D2 canon 60/60; D3/D4 60/60
- audit_conformance.json: A1--A12 pass; seven failure codes covered
- taxonomy_ag.json: A--G synthetic + M2 live D
- ab_contract_baselines.json: AB0--AB3 isolation study
- mechanism_cards.json: T1--T8 pass (conformance only)
- m2_waterfall.json: D_token_mapping_failure
- sealed primary Table-4 cells are NOT mutated by these scripts
- supplemental live L1--L4: see results/raw/supplemental_live/ (evidence classes per path)

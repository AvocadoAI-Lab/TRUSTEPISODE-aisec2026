# TrustEpisode reproducibility companion (AISec 2026)

This anonymous archive contains a portable reference runtime, executable synthetic checks,
sealed results, contracts, generated tables, and a claim-to-evidence matrix. The manuscript
source is intentionally excluded because embedding a source file that states the archive's own
SHA-256 would create a self-referential stale digest. The submitted PDF's
**Artifact Digest** paragraph records the authoritative SHA-256 of this archive.

## Portable one-command check

```bash
python -m pip install -r requirements.txt
python scripts/run_companion_checks.py
```

The command first fails closed unless Python imports the runtime from this extracted archive.
It then runs the packaged reference-runtime test suite and re-runs A1--A12, A--G, AB0--AB3,
AI0--AI7, T1--T8, the inclusive temporal boundary fixtures, contract validation, table
generation, and the claim verifier.

## Evidence modes

- **Re-executable from this archive:** packaged-runtime origin validation; the 38-test reference
  runtime suite; A1--A12 audit conformance; A--G taxonomy; AB0--AB3 contract isolation;
  AI0--AI7 agent-boundary mutations; T1--T8 mechanism cards; temporal boundary fixtures at
  299/300/301 and 3599/3600/3601/3900 seconds.
- **Regenerated from sealed JSON:** LaTeX macros and result tables.
- **Integrity/claim checked from sealed outputs:** D1--D5 determinism summaries, fair-baseline
  summaries, M2 waterfall, supplemental L1--L4 results, and both held-out local-model audits.
- **Not re-executed from this archive:** live collection, offline cohort re-synthesis requiring
  omitted raw lab bundles, or Ollama model inference. The two model raw/derived JSON files are
  byte-compared and their frozen digests and reported scores are checked.

For anonymous review, absolute local `source_path` values in supplemental live-result copies are
replaced with `<ANONYMIZED_LAB_ROOT>`; run IDs, observations, measurements, and outcome fields are
unchanged. The author-retained sealed originals are not modified.

Expected headline values include 0/69/1 EB4-vs-EB1 action-coverage W/T/L, 60/60 D1 canonical
replay, 8/8 AI0--AI7 specified outcomes, 9/20 fully exact Qwen responses, and 0/20 fully exact Gemma
responses. These are bounded artifact claims, not production-readiness or general model-accuracy
claims.

## Anonymous-review publication

If the venue requests an artifact URL, publish this exact ZIP through an anonymous repository
or other organizer-approved anonymous mechanism. Do not link an author-identifying source
repository. Reviewers can compare the downloaded ZIP with the SHA-256 printed in the submitted
paper before extracting and running it.

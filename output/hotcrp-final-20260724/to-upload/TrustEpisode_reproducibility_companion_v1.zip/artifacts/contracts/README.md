# TrustEpisode machine-readable contracts

These files define the frozen schemas, thresholds, registries, scenario cards, examples, and
validation rules used by the paper. They are method and audit artifacts; pending protocols are
not represented as completed experiments.

Run `python artifacts/contracts/validate_contracts.py` from the companion root.
Operational dashboard/control-plane mirrors are downstream consumers of sealed copies and are
excluded from the primary RT1--RT7 inputs, denominators, and results.
